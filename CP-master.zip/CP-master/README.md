# CP

### Problema 1

**1** Feito

**2** Feito

**3** Feito

### Problema 2

**1** Todas feitas (falta algum refactoring)

**2** Por fazer

**3** Por fazer

### Problema 3

Feito

### Problema 4

Por fazer

### Problema 5

Por fazer
